./ore mine --threads 4 --rpc https://node.onekey.so/sol --keypair ./1.json
